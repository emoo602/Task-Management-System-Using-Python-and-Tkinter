import tkinter as tk
from tkinter import ttk, messagebox

class Task:
    def __init__(self, description, priority, completed=False):
        self.description = description
        self.priority = priority
        self.completed = completed

class TaskManager:
    def __init__(self):
        self.tasks = {}

    def add_task(self, task):
        if task.description in self.tasks:
            return False
        self.tasks[task.description] = task
        return True

    def delete_task(self, description):
        return self.tasks.pop(description, None) is not None

    def find_task(self, description):
        return self.tasks.get(description, None)

    def update_task(self, description, new_priority):
        if description in self.tasks:
            self.tasks[description].priority = new_priority
            return True
        return False

    def mark_completed(self, description):
        if description in self.tasks:
            self.tasks[description].completed = True
            return True
        return False

    def get_all_tasks(self):
        return list(self.tasks.values())

task_manager = TaskManager()

root = tk.Tk()
root.title("Task Manager")
root.geometry("600x500")
root.configure(bg="#f4f4f4")

frame_input = tk.Frame(root, bg="#f4f4f4")
frame_input.pack(pady=10)

tk.Label(frame_input, text="Task Description:", bg="#f4f4f4").grid(row=0, column=0, padx=5, pady=5)
entry_desc = tk.Entry(frame_input, width=30)
entry_desc.grid(row=0, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Priority:", bg="#f4f4f4").grid(row=1, column=0, padx=5, pady=5)
priority_var = tk.StringVar()
priority_menu = ttk.Combobox(frame_input, textvariable=priority_var, values=["High", "Medium", "Low"], state="readonly", width=27)
priority_menu.grid(row=1, column=1, padx=5, pady=5)
priority_menu.current(1)

frame_table = tk.Frame(root)
frame_table.pack(pady=10)

columns = ("Description", "Priority", "Completed")
task_table = ttk.Treeview(frame_table, columns=columns, show="headings", height=8)
task_table.heading("Description", text="Description")
task_table.heading("Priority", text="Priority")
task_table.heading("Completed", text="Completed")
task_table.column("Description", width=220)
task_table.column("Priority", width=80)
task_table.column("Completed", width=80)
task_table.pack()

def refresh_task_table():
    task_table.delete(*task_table.get_children())
    for task in task_manager.get_all_tasks():
        task_table.insert("", "end", values=(task.description, task.priority, "Yes" if task.completed else "No"))

def add_task():
    desc = entry_desc.get().strip()
    priority = priority_var.get()
    if not desc:
        messagebox.showerror("Error", "Task description cannot be empty!")
        return
    task = Task(desc, priority)
    if task_manager.add_task(task):
        messagebox.showinfo("Success", "Task added successfully!")
        refresh_task_table()
        entry_desc.delete(0, tk.END)
    else:
        messagebox.showerror("Error", "Task already exists!")

def delete_task():
    selected_item = task_table.selection()
    if not selected_item:
        messagebox.showerror("Error", "Please select a task to delete!")
        return
    task_desc = task_table.item(selected_item, "values")[0]
    if task_manager.delete_task(task_desc):
        messagebox.showinfo("Success", f"Task '{task_desc}' deleted!")
        refresh_task_table()
    else:
        messagebox.showerror("Error", "Task not found!")

def search_task():
    desc = entry_desc.get().strip()
    task = task_manager.find_task(desc)
    if task:
        messagebox.showinfo("Task Found", f"Description: {task.description}\nPriority: {task.priority}\nCompleted: {'Yes' if task.completed else 'No'}")
    else:
        messagebox.showerror("Not Found", "Task not found!")

def update_task():
    selected_item = task_table.selection()
    if not selected_item:
        messagebox.showerror("Error", "Please select a task to update!")
        return
    task_desc = task_table.item(selected_item, "values")[0]
    new_priority = priority_var.get()
    if task_manager.update_task(task_desc, new_priority):
        messagebox.showinfo("Success", f"Task '{task_desc}' updated!")
        refresh_task_table()
    else:
        messagebox.showerror("Error", "Task not found!")

def mark_completed():
    selected_item = task_table.selection()
    if not selected_item:
        messagebox.showerror("Error", "Please select a task to mark as completed!")
        return
    task_desc = task_table.item(selected_item, "values")[0]
    if task_manager.mark_completed(task_desc):
        messagebox.showinfo("Success", f"Task '{task_desc}' marked as completed!")
        refresh_task_table()
    else:
        messagebox.showerror("Error", "Task not found!")

frame_buttons = tk.Frame(root, bg="#f4f4f4")
frame_buttons.pack(pady=10)

btn_add = tk.Button(frame_buttons, text="Add Task", command=add_task, bg="lightgreen", width=15)
btn_add.grid(row=0, column=0, padx=5, pady=5)

btn_delete = tk.Button(frame_buttons, text="Delete Task", command=delete_task, bg="red", width=15)
btn_delete.grid(row=0, column=1, padx=5, pady=5)

btn_search = tk.Button(frame_buttons, text="Search Task", command=search_task, bg="yellow", width=15)
btn_search.grid(row=1, column=0, padx=5, pady=5)

btn_update = tk.Button(frame_buttons, text="Update Priority", command=update_task, bg="orange", width=15)
btn_update.grid(row=1, column=1, padx=5, pady=5)

btn_complete = tk.Button(frame_buttons, text="Mark Completed", command=mark_completed, bg="blue", fg="white", width=15)
btn_complete.grid(row=2, column=0, columnspan=2, pady=5)

refresh_task_table()
root.mainloop()
